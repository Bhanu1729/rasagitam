# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions


# This is a simple example for a custom action which utters "Hello World!"

from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher

times ={
    "monday":"9-10:EID301,10-11:EId302",
    "tuesday":"9-10:EID303,10-11:EId304",
    "wednesday":"9-10:EID305,10-11:EId306",
    "thursday":"9-10:EID303,10-11:EId304",
    "friday":"9-10:EID305,10-11:EId306",
    "saturday":"9-10:EID301,10-11:EId302",
    "sunday":"holiday",
}

subs ={
   "EID301":"C lang",
   "EID302":"Java",
   "EID303":"python",
   "EID304":"COA",
   "EID305":"DBMS",
   "EID306":"FLAT",

}

class Showtimetable(Action):

    def name(self) -> Text:
        return "show_time_table"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        days = tracker.get_slot("days")
        time = times.get(days)
        if time is None:
            output = "could not find the timetable of {}".format(days)
        else:
            output = "time able of {} is {}\n".format(days,time)

        dispatcher.utter_message(text= output)

        return []


class Nameofcourse(Action):

    def name(self) -> Text:
        return "name_of_course"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        courses = tracker.get_slot("courses")
        sub = subs.get(courses)
        if sub is None:
            output = "could not find the timetable of {}".format(courses)
        else:
            output = "time able of {} is {}".format(courses,sub)

        dispatcher.utter_message(text= output)

        return []

