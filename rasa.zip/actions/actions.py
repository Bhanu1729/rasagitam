# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions


# This is a simple example for a custom action which utters "Hello World!"

from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher

times ={
    "monday":"for CSE 9-10:ECS 401,10-11:EID 403,11-12:EID 405 for ECE 9-10:EID 321,10-11: EID 315,11-12:EID 325",
    "Tuesday":"for CSE 9-10:EID 405,10-11:EId 403,11-12:ECS 401 for ECE  9-10:EID325,10-11:EID 321,11-12:EID315",
    "wednesday":"for CSE 9-10:ECS 401,10-11:EID 405,11-12:EID 403 for ECE 9-10:EID 325,10-11: EID 315,11-12:EID 321",
    "thursday":"for CSE 9-10:EID 403,10-11:EID 405,11-12:ECS 401 for ECE 9-10:EID 315,10-11: EID 321,11-12:EID 325",
    "friday":"for CSE 9-10:EID 403,10-11:ECS 401,11-12:EID 405 for ECE 9-10:EID 321,10-11: EID 325,11-12:EID 315",
    "saturday":"for CSE 9-10:ECS 401,10-11:EID 403for ECE 9-10:EID 321,10-11:EID 315",
    "sunday":"holiday",
}
 
subs ={
   "ECS401":"Cryptography",
   "EID403":"Machine learning",
   "EID405":"Cloud Computing",
   "EID321":"COA",
   "EID315":"DBMS",
   "EID325":"FLAT",
 
}
modes ={
    "ECS401":"full-time",
    "EID403":"full-time",
    "EID405":"online",
    "EID321":"part-time",
    "EID315":"flexible",
    "EID325":"part-time",
}


package ={
    "Amazon":"21lakhs",
    "Infytq":"3.60lakhs",
    "Hackwithinfy":"3.60lakhs",
    "Tek System":"6.0lakhs",
    "Virtusa":"4.0lakhs",
    "Wipro":"3.5lakhs",
    "DXC":"3.6lakhs",
    "Mindtree":"4.0lakhs",
    "TCS":"3.36lakhs",
    "Legato":"4.25lakhs",
    "Capgemini":"3.80lakhs",
    "Cisco":"14lakhs",
    "HexaWare":"3.5lakhs",
    "Winman Software":"6.0lakhs",
    "ThoughtClan":"4.5lakhs",
    "JaroGroup":"6.60lakhs",
    "cognizant":"4.50lakhs",
    "TCSNQT":"3.36lakhs",
}
placed2 ={
    "Amazon":"1",
    "Infytq":"0",
    "Hackwithinfy":"1",
    "Tek System":"0",
    "Virtusa":"8",
    "Wipro":"33",
    "DXC":"89",
    "Mindtree":"37",
    "TCS":"4",
    "Legato":"109",
    "Capgemini":"22",
    "Cisco":"1",
    "HexaWare":"3",
    "Winman Software":"2",
    "ThoughtClan":"2",
    "JaroGroup":"0",
    "cognizant":"73",
    "TCSNQT":"64",
}
placed1 ={
    "Amazon":"0",
    "Infytq":"0",
    "Hackwithinfy":"0",
    "Tek System":"0",
    "Virtusa":"1",
    "Wipro":"59",
    "DXC":"14",
    "Mindtree":"1",
    "TCS":"5",
    "Legato":"18",
    "Capgemini":"0",
    "Cisco":"0",
    "HexaWare":"0",
    "Winman Software":"0",
    "ThoughtClan":"1",
    "JaroGroup":"0",
    "cognizant":"36",
    "TCSNQT":"43",
}



class Showtimetable(Action):

    def name(self) -> Text:
        return "show_time_table"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        days = tracker.get_slot("days")
        time = times.get(days)
        if time is None:
            output = "could not find the timetable of {}".format(days)
        else:
            output = "time table of {} is {}\n".format(days,time)

        dispatcher.utter_message(text= output)

        return []



class Nameofcourse(Action):

    def name(self) -> Text:
        return "name_of_course"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        courses = tracker.get_slot("courses")
        sub = subs.get(courses)
        if sub is None:
            output = "could not find the course name of {}".format(courses)
        else:
            output = "course name of {} is {}".format(courses,sub)

        dispatcher.utter_message(text= output)

        return []

class Modeofcourse(Action):

    def name(self) -> Text:
        return "mode_of_course"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        courses = tracker.get_slot("courses")
        mode = modes.get(courses)
        if mode is None:
            output = "could not find the mode of course {}".format(courses)
        else:
            output = "mode of course {} is {}\n".format(courses,mode)

        dispatcher.utter_message(text= output)

        return []

class Showpackage(Action):

    def name(self) -> Text:
        return "show_package"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        com = tracker.get_slot("com")
        pack = package.get(com)
        if pack is None:
            output = "could not find the pacakge of {}".format(com)
        else:
            output = "package  of {} is {}\n".format(com,pack)

        dispatcher.utter_message(text= output)

        return []  

class placedstudent2021(Action):

    def name(self) -> Text:
        return "placed_student2021"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        com = tracker.get_slot("com")
        place = placed2.get(com)
        if place is None:
            output = "enter proprer company {}".format(com)
        else:
            output = "no of students placed in {} is {}\n".format(com,place)

        dispatcher.utter_message(text= output)

        return []

class placedstudent2020(Action):

    def name(self) -> Text:
        return "placed_student2020"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        com = tracker.get_slot("com")
        place = placed1.get(com)
        if place is None:
            output = "enter proper company {}".format(com)
        else:
            output = "no of students placed in {} is {}\n".format(com,place)

        dispatcher.utter_message(text= output)

        return []

